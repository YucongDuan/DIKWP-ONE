# Adversarial attention and value-return threat model

This project assumes that scarcity, incentives and power shape open-source outcomes.

## T1. Complexity abandonment

**Likely behaviour:** visitors leave before understanding the architecture.

**Countermeasure:** one sentence, one button, one output. Theory is available after use.

## T2. Canonical ambiguity

**Likely behaviour:** outsiders cannot tell which of hundreds of repositories is the current entry.

**Countermeasure:** one pinned repository, one profile link and a new-repository freeze.

## T3. Attribution stripping

**Likely behaviour:** useful ideas are reused while the conceptual origin disappears.

**Countermeasure:** `origin.json`, `CITATION.cff`, NOTICE, origin fields and digests in every exported card and receipt.

## T4. Free-support extraction

**Likely behaviour:** organizations request private customization without funding maintenance.

**Countermeasure:** public issues for community support; recurring or organization-specific work becomes a scoped paid pilot.

## T5. Social-proof waiting

**Likely behaviour:** each institution waits for another institution to adopt first.

**Countermeasure:** publish outcome receipts, including small results and failures, rather than more promises.

## T6. Founder substitution

**Likely behaviour:** every module, answer and support request returns to one exhausted founder.

**Countermeasure:** no feature without an external owner; one weekly triage window; maintainership is a first-class adoption path.

## T7. Novelty treadmill

**Likely behaviour:** platform attention rewards another new repository, while cumulative trust declines.

**Countermeasure:** new ideas become issues or modules. A public repository requires an adopter, maintainer, dataset, experiment, standard interface, funding or legal separation.

## T8. Praise without return

**Likely behaviour:** visitors express admiration but create no adoption, evidence, maintenance or material return.

**Countermeasure:** every public pathway asks for one concrete return: use, result, maintenance or pilot.

## T9. Defensive-language penalty

**Likely behaviour:** a README dominated by exclusions and caveats is interpreted as uncertainty or lack of utility.

**Countermeasure:** lead with the user outcome. Put necessary boundaries near the relevant action, not before the value is visible.

## T10. Closed capture

**Likely behaviour:** an organization internalizes the open tool and does not return improvements.

**Countermeasure:** preserve machine-readable origin, invite public adoption registration, and sell maintained implementation rather than assuming moral reciprocity.
