# Support boundary

DIKWP ONE is open source. The founder is not an unlimited private support queue.

## Public community support

Use a GitHub Issue for:

- a reproducible bug;
- a proposed correction;
- an adoption result;
- a small maintainable contribution;
- a public integration question that benefits other users.

Do not include confidential, personal, medical, legal or commercial data.

## Scoped implementation

Organization-specific recurring work belongs in a scoped pilot with:

- one workflow;
- one accountable owner;
- one data boundary;
- one measurable result;
- one budget or committed staff-time path;
- one keep/change/stop decision.

See `PILOT.md` and `COMMERCIAL_SERVICES.md`.

## Response model

Public triage is batched. A request may be closed when it lacks reproduction, ownership, measurable benefit or sustainable maintenance. This is a product-health rule, not a judgment of the requester.
