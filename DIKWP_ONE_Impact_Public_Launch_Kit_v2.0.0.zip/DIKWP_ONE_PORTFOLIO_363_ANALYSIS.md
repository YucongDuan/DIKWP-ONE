# Portfolio 363: public diagnosis and reset

Snapshot date: 2026-08-17  
Public profile: `https://github.com/YucongDuan?tab=repositories`

## Observed public state

The current public profile displayed:

- 363 repositories;
- 0 account-level Projects;
- 0 account-level Packages;
- 583 items in the profile Stars tab;
- 663 followers;
- 2.1k following.

The Stars tab is not used here as an aggregate measure of stars received by YucongDuan repositories.

The newest public page is dominated by a rapid sequence of systems around artificial consciousness, ultimate value, justice-energy, responsibility, truth, active medicine, proof metabolism, provenance and value return. Many of those repositories show only one to three visible stargazers on the public listing.

This is not evidence that the ideas are weak. It is evidence that the portfolio is forcing outsiders to pay a very high interpretation cost before they receive a concrete benefit.

## The hard diagnosis

The portfolio has crossed from abundance into **attention self-competition**.

Every new repository now competes with hundreds of siblings for:

- the same founder's maintenance time;
- the same followers' attention;
- the same external reviewers;
- the same search terms;
- the same citation and attribution path;
- the same potential adopters and buyers.

A new repository may add one artifact while subtracting visibility from the entire portfolio.

The current front page also shows that commercialization, attribution, truth, active medicine and responsibility have already received dedicated repositories. Creating another meta-system about commercialization would repeat the structural problem.

## What outsiders are likely to do

An adversarial but realistic model of external behaviour predicts that many visitors will:

1. scan the first screen for less than a minute;
2. use stars, familiar words and runnable demos as shortcuts;
3. avoid evaluating grand or unfamiliar claims without independent proof;
4. borrow useful fragments while omitting the larger conceptual origin;
5. praise publicly but avoid taking maintenance responsibility;
6. request custom help privately because it is cheaper than sponsoring a project;
7. wait for another institution to validate the work first;
8. treat a large number of similar repositories as evidence that none is canonical.

The response cannot be another explanation asking people to behave better. The product must change their available path.

## The reset decision

For the next 60 days, the canonical public strategy should be:

```text
363 repositories
→ 1 pinned front door
→ 1 tool usable in 60 seconds
→ 1 result receipt
→ 1 public issue queue
→ 1 scoped pilot funnel
```

DIKWP ONE is that front door.

## Why this tool, not another theory portal

The portfolio's transferable core is not a specific philosophical claim. It is the repeated transformation:

```text
raw input
→ differences and uncertainty
→ bounded understanding
→ affected-party value
→ purposeful action
→ observed world effect
→ correction
```

That pattern can be used before an outsider accepts the full DIKWP vocabulary. DIKWP ONE therefore starts with a familiar pain: AI gives answers, but people still do not know what to do next or who owns the result.

## Three flagship pilot wedges

These are not three new products. They are three purchasing contexts for the same product.

### 1. AI action review

**Buyer problem:** an AI agent produces an answer or proposes a tool call, but the organization cannot see evidence, affected parties, ownership and revisit conditions on one page.

**Pilot outcome:** one workflow produces Action Cards before execution and Outcome Receipts after execution.

### 2. Evidence-to-decision

**Buyer problem:** research, policy and procurement teams accumulate documents but do not convert them into one accountable decision.

**Pilot outcome:** one decision process gains a canonical evidence/action/result chain.

### 3. Institutional handoff

**Buyer problem:** responsibility disappears when work moves between teams.

**Pilot outcome:** owner, date, affected-party feedback and correction survive the handoff.

## New-repository gate

A new repository should be rejected or converted into a module unless at least one of the following is already named:

- a new external maintainer;
- a new real adopter;
- a new dataset unavailable to existing projects;
- a new falsifiable experiment;
- a new standards interface;
- a funded or paid workflow;
- a legally necessary separation.

An idea, a new name, a new diagram or a new report is not sufficient.

Run:

```bash
python run.py repo-gate examples/new_repo_proposal.json
```

## Public success metrics

Do not use repository count as the primary success measure. Publish these instead:

- completed Action Cards;
- Outcome Receipts with observed results;
- external maintainers;
- independent use cases;
- pilot requests;
- funded pilots;
- repeat organizational users;
- corrections completed;
- founder hours returned or delegated.

## 30-day stop condition

After 30 days, continue only if the repository has produced at least two of:

- five external Action Cards;
- one external maintainer;
- one reproducible result report;
- one qualified pilot conversation;
- one real integration proposal.

If it has not, do not create another repository. Interview users, simplify the promise and change distribution.
