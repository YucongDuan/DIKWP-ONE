## Start here

### [DIKWP ONE](https://github.com/YucongDuan/DIKWP-ONE)

**One AI answer → one accountable action → one observed result.**

Local-first, no account, open source. This is the canonical public front door to the wider DIKWP portfolio.
