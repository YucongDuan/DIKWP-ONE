# Maintained implementation and paid pilots

The public tool is open source. Organizations may commission maintained implementation, integration and training.

## Two-week Action Card sprint

Deliverables:

- one selected workflow;
- one decision-input template;
- one Action Card template;
- one Outcome Receipt template;
- one named owner and review process;
- one deployment or handover session;
- one result note.

## Six-week team adoption pilot

Deliverables:

- up to three workflows;
- local or private deployment;
- role and data-boundary mapping;
- workflow integration;
- adoption and outcome measures;
- maintainer training;
- final keep/change/stop decision.

## Custom integration

Suitable for agent gateways, research evidence flows, procurement, hospital quality offices and public-service review processes.

## Intake

Open a `Pilot request` issue without confidential data. The maintainer may move qualified conversations to a private channel after scope, owner, budget range and desired result are clear.

No public document creates a binding quote or commitment. Scope, price and responsibility are established in a separate agreement.
