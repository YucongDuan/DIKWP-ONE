# Pilot format

A pilot is the path for organization-specific work. It is not an open-ended request for free customization.

## Minimum qualification

A pilot request must name:

- one workflow;
- one accountable owner;
- one measurable before/after result;
- one data boundary;
- one decision window;
- one budget owner or funding path.

## Two-week blueprint

- map the current answer-to-action handoff;
- configure one Action Card;
- configure one Outcome Receipt;
- train the owner and one backup;
- run at least five cases;
- produce a keep/change/stop note.

## Good candidates

- agent output review before tool execution;
- research evidence-to-action handoff;
- procurement or product decision brief;
- hospital quality or safety workflow;
- public-service explanation and appeal handoff;
- cross-team owner and review-date preservation.

Open a `Pilot request` issue. Do not place confidential information in a public issue.
