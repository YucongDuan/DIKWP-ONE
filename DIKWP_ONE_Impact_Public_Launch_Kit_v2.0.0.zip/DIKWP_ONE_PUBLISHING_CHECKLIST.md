# GitHub publishing checklist

## Canonical repository

- [ ] Repository name is exactly `DIKWP-ONE`.
- [ ] Upload the expanded source tree, not only the ZIP.
- [ ] Default branch is `main`.
- [ ] About text: `One AI answer. One accountable action. One result.`
- [ ] Homepage points to GitHub Pages.
- [ ] Topics include `ai`, `decision-making`, `agent-governance`, `evidence`, `dikwp`, `local-first`.

## Visibility

- [ ] Pin `DIKWP-ONE` as the first profile repository.
- [ ] Add `PROFILE_README_SNIPPET.md` to the profile README.
- [ ] Enable Issues and Discussions.
- [ ] Enable GitHub Pages.
- [ ] Upload `docs/social-preview.png` as the repository social preview.

## Energy protection

- [ ] Announce the 60-day related-repository freeze.
- [ ] Set one weekly triage window.
- [ ] Do not publish a parallel ResearchGate report before five external uses.
- [ ] Route custom work to the pilot issue form.
- [ ] Assign at least one external maintainer candidate.

## Launch

- [ ] Post the reviewed launch text.
- [ ] Publish a 30-second screen recording.
- [ ] Invite 20 targeted users.
- [ ] Schedule the Day-7 result note.
