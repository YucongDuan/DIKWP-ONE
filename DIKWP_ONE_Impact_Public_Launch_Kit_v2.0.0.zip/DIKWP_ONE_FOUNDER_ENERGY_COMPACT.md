# Founder-energy compact

Effective for the first 60 days after public release.

## Non-negotiable rules

1. No new public repository for a related idea.
2. One scheduled public triage window per week.
3. Direct messages are not a support queue.
4. No feature enters the roadmap without an external owner or a verified adopter.
5. Organization-specific recurring work becomes a paid pilot.
6. Publish one real result per week, including failures and corrections.
7. The founder does not prepare a bespoke long report before a qualified user has tried the tool.
8. A new document must replace, update or operationalize an existing canonical document; otherwise it remains an issue note.

## Energy ledger

A recurring activity must return at least one of:

- verified adoption;
- external maintenance;
- reproducible evidence;
- funding or paid work;
- citation or attribution;
- reusable product improvement;
- measurable reduction in future support load.

If it returns none for two cycles, automate, delegate, reduce or stop it.

## Founder availability

The public promise is maintained software and a clear pilot process—not unlimited personal access to the founder.
