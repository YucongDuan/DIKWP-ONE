# 30-day public launch

## Before publication

- Create or reset the canonical `YucongDuan/DIKWP-ONE` repository.
- Upload source, not only a ZIP.
- Enable Issues and Discussions.
- Enable GitHub Pages from the repository root or workflow.
- Pin the repository first on the profile.
- Replace the profile's first sentence with the short snippet in `PROFILE_README_SNIPPET.md`.
- Do not launch another repository during this period.

## Day 0

Publish one honest reset message from `PUBLIC_LAUNCH_TEXT.md` and a 30-second screen recording:

```text
paste answer → create card → export result
```

## Days 1–3

Invite 20 specific people, not a mass audience:

- five AI-agent builders;
- five research or evidence leads;
- five institution workflow owners;
- five open-source maintainers.

Ask each person to do one thing: create one card and report one friction point.

## Day 7

Publish the first result note:

- number of external cards;
- what users changed;
- one failure;
- one correction;
- next single roadmap item.

## Day 14

Hold one public 30-minute demo. Do not present the 363-repository history. Demonstrate one input, one card and one result receipt.

## Day 21

Contact only qualified organizations that already have:

- a workflow owner;
- a recurring AI/evidence handoff problem;
- a result they can measure;
- authority to run a small pilot.

## Day 30

Use the stop condition in `PORTFOLIO_363_ANALYSIS.md`. Continue, simplify or reposition. Do not respond to weak traction by creating another repository.
