# Public adoption registry

This file is intentionally empty at release. Add only externally confirmed uses that may be cited publicly.

| Date | Organization or public alias | Workflow | Observed result | Evidence | Permission to cite |
|---|---|---|---|---|---|

Rules:

- no invented adopters;
- no confidential data;
- no result without an observed Outcome Receipt;
- record failure and correction as well as success;
- remove an entry if the adopter withdraws permission.
